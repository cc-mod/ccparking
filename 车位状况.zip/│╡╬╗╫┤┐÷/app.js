//app.js
App({
  onLaunch: function () {
    //调用API从本地缓存中获取数据
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    try {
      var res = wx.getSystemInfoSync()
      console.log(res.model)
      console.log(res.pixelRatio)
      console.log(res.windowWidth)
      console.log(res.windowHeight)
      console.log(res.language)
      console.log(res.version)
      console.log(res.platform)
      this.globalData.windowWidth=res.windowWidth;
      this.globalData.windowHeight=res.windowHeight;
    } catch (e) {
      // Do something when catch error
    }

    
  },
  getUserInfo:function(cb){
    var that = this
    if(this.globalData.userInfo){
      typeof cb == "function" && cb(this.globalData.userInfo)
    }else{
      //调用登录接口
      wx.login({
        success: function () {
          wx.getUserInfo({
            success: function (res) {
              that.globalData.userInfo = res.userInfo
              typeof cb == "function" && cb(that.globalData.userInfo)
            }
          })
        }
      })
    }
  },
  globalData:{
    userInfo:null,
    windowWidth:0,
    windowHeight:50,
    serviceUrl:'http://localhost:53658/api'
  }
})
const AV = require('/utils/av-weapp');

App({

  onLaunch: function () {

    AV.init({
      appId: 'pPi8iPBIoE1K6xLlNbW8iV86-gzGzoHsz',
      appKey: 'ersbaFq0nAGSU3kY0TptHLUo',
    });

    AV.User.loginWithWeapp().then(user => {
      this.globalData.user = user.toJSON();
      this.globalData.userid = this.globalData.user.objectId;
      console.log(this.globalData.userid)
    }).catch(console.error);

  },

  globalData: {
    userInfo: null,
    user: [],
    userid: 0,
    state_flag: 0,
    timer_flag: 0,
    start_time: 0,
    start_data: {},
    local: [],
    objectID: [],
  }
})