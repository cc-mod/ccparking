// pages/detail/detail.js
Page({
  data:{
    imgUrls: [
      'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1526722355151&di=67aa7d7509fcfab5e0bc4686ba5a70a2&imgtype=0&src=http%3A%2F%2Fimg2.sdaxue.com%2F69386fb5-50bc-a955-fe54-2d524c2c7c87.jpg'
    ],
    indicatorDots: false,
    autoplay: false,
    interval: 5000,
    duration: 1000,
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  },
  openLocation:function(){
    wx.openLocation({
      latitude: 29.3290603354, // 纬度，范围为-90~90，负数表示南纬
      longitude: 117.3138141632, // 经度，范围为-180~180，负数表示西经
      scale: 28, // 缩放比例
      name: '景德镇陶瓷大学研究生楼停车场', // 位置名
      address: '景德镇陶瓷大学研究生楼'// 地址的详细说明
    })
  },
  preOrder:function(){
    wx.navigateTo({
      url: '../preOrder/preOrder'
    })
  }
  
})