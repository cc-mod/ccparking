//index.js
//获取应用实例
var app = getApp()
Page({
  data: {
    markers: [{
      iconPath: "/images/park.png",
      id: 0,
      latitude: 29.3307252669,
      longitude: 117.3179984093,
      width: 40,
      height: 48,
    }, {
      iconPath: "/images/park.png",
      id: 1,
      latitude: 29.3258239301,
      longitude: 117.3187279701,
      width: 40,
      height: 48,
    }, {
      iconPath: "/images/park.png",
      id: 1,
      latitude: 29.3285739458,
      longitude: 117.3133635521,
      width: 40,
      height: 48,
    }, {
      iconPath: "/images/park.png",
      id: 1,
      latitude: 29.328573858,
      longitude: 117.3133639001,
      width: 40,
      height: 48,
    }],
    polyline: [{
      points: [{
        longitude: 117.3133639001,
        latitude: 29.3285739458
      }, {
          longitude: 117.3133639001,
          latitude: 29.32857
      }],
      color: "#FF0000DD",
      width: 2,
      dottedLine: true
    }]
    // controls: [{
    //   id: 1,
    //   iconPath: '/images/car.png',
    //   position: {
    //     left: app.globalData.windowWidth/2-32,
    //     top: app.globalData.windowHeight/2-84,
    //     width: 64,
    //     height: 64
    //   },
    //   clickable: true
    // }]
  },
  onLoad: function (e) {

  },
  regionchange(e) {
    console.log(e.type)
  },
  markertap(e) {
    console.log(e.markerId)
  },
  controltap(e) {
    console.log(e.controlId)
  },
  bindParkingListItemTap: function () {
    wx.navigateTo({
      url: "../detail/detail"
    })
  },
  openParkingMap: function () {
    wx.navigateTo({
      url: '../parkinglotMap/parkinglotMap',
      success: function (res) {
        // success
      },
      fail: function (res) {
        // fail
      },
      complete: function (res) {
        // complete
      }
    })
  }
})
